#! /bin/bash

source ./overlight.sh
source ./overlightUI.sh
source ./overlighttool.sh
date