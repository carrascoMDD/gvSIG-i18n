#! /bin/bash

source ./genonly.sh
source ./override.sh
source ./deplight.sh