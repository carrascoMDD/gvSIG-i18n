#! /bin/bash

source ./genonly.sh
source ./override.sh
source ./dep.sh
date