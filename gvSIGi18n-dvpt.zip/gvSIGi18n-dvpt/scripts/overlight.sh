#! /bin/bash


source ./override.sh

source ./deplight.sh

date