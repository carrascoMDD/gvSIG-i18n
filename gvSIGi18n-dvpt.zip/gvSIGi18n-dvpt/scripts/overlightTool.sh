#! /bin/bash

source ./overrideTool.sh

source ./deplightTool.sh

date