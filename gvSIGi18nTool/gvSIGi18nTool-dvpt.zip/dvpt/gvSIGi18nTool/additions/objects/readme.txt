gvSIGi18nTool is the front-end (facade) to all services supplied by gvSIGi18n elements, implemented by classes in the gvSIGi18n product.

The user interface components in gvSIGi18nUI product delegate in this gvSIGi18nTool to execute behavior on gvSIGi18n elements.

