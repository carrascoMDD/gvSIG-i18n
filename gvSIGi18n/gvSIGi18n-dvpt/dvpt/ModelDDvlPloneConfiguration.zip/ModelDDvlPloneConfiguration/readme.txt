Overview

  ModelDDvlPlone and its companion ModelDDvlPloneTool
  provide respectively the skins (visual presentation)
  and logic (retrieve, modify) to manage the creation of 
  complex Archetypes networks, including their linkage
  through relations.
  
  
Dependencies
  ModelDDvlPlone and its companion ModelDDvlPloneTool
  require the installation of the products "Relations"
  and "PloneLanguageTool". 
  
  Installation will fail if these products are not 
  correctly deployed and available in the Plone instance.
  
  The installer will automatically install the prerequisite
  products, if corretly deployed and available in the Plone instance.
  
  
Copyright

  Copyright (c) 2008 by 2008 Model Driven Development sl and Antonio Carrasco Valero
  
  
  
Authors

  Model Driven Development sl  Valencia (Spain):http://www.ModelDD.org 
  Antonio Carrasco Valero                       carrasco@ModelDD.org

  
License

  GNU General Public License (GPL)
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
  02110-1301, USA.
  
  
