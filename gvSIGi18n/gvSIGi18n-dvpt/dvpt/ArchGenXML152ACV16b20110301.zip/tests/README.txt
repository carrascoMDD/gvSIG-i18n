Directory with tests for ArchGenXML, started 2005-04-09.

At the moment there's only one testfile, you can run it from
ArchGenXML's main directory:

'python tests/testPyParser.py'

