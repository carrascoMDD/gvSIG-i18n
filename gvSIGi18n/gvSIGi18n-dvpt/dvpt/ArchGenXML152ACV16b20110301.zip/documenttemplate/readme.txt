this module has been borrowed from Zope3 (svn.zope.org)
